

<ui-close data-flux-modal-close <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</ui-close>
<?php /**PATH C:\Users\User\Herd\email-manager\vendor\livewire\flux\src/../stubs/resources/views/flux/modal/close.blade.php ENDPATH**/ ?>